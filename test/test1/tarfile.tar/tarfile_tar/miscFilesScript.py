import os
import subprocess
import logging
import zipfile
import shutil


logging.basicConfig(level=logging.DEBUG, filename='miscfiles.log', filemode='w', format='%(asctime)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S')
CURRENT_PATH = os.path.dirname(os.path.abspath(__file__))

POC_REPO_URL = "https://github.com/MoneshKumar/binarypoc.git"
MISC_REPO_URL = "https://github.com/MoneshKumar/test.git"
POC_DIR = os.path.join(CURRENT_PATH, "poc")
MISC_DIR = os.path.join(CURRENT_PATH, "misc")
DEFAULT_MISC_LIST = [".txt", ".docx", ".xlsx"]

class MiscFiles:

    def clone_repo(self, repo_dir, repo_url):
        try:
            if os.path.exists(repo_dir):
                pass
                #os.system("rm -r " + repo_dir)
                #os.system("mkdir " + repo_dir)
            else:
                os.system("mkdir " + repo_dir)
            os.chdir(repo_dir)
            os.system("git init")
            os.system("git clone " + repo_url)
            logging.debug(f"{repo_url} repository cloned.")
        except Exception as e:
            logging.exception(f'{e}')

    def unzip_files(self):
        zip_files_list = []
        for root, dirs, files in os.walk(POC_DIR):
            for file in files:
                if file.endswith(".zip"):
                    zip_file = os.path.join(root, file)
                    zip_files_list.append(zip_file)
                    zip_ref = zipfile.ZipFile(zip_file, 'r')
                    zip_ref.extractall(root)
                    zip_ref.close()
                    logging.debug(f"{zip_file} extracted.")
                    os.system("rm '" + zip_file + "'")
        #print(zip_files_list)

    def track_misc_files(self):
        misc_files_list = []
        for root, dirs, files in os.walk(POC_DIR):
            for file in files:
                if file.endswith(tuple(DEFAULT_MISC_LIST)) and file != "misc_metadata.txt":
                    filepath = os.path.join(root, file)
                    filepath = filepath.replace(POC_DIR, "")
                    misc_files_list.append(filepath)
        misc_files_list_count = len(misc_files_list)
        logging.debug(f"{misc_files_list_count} miscellaneous files tracked.")
        #print(misc_files_list)
        return misc_files_list

    def move_misc_files(self, misc_files_list):
        os.chdir(CURRENT_PATH)
        self.clone_repo(MISC_DIR, MISC_REPO_URL)

        metafile = open(os.path.join(POC_DIR, "binarypoc", "misc_metadata.txt"), "w+")
        dstroot = os.path.join(MISC_DIR, "test")

        for file in misc_files_list:

            fildir = os.path.dirname(file)
            dstdir =  dstroot + fildir.replace("\\binarypoc", "")
            try:
                os.makedirs(dstdir) # create all directories, raise an error if it already exists
            except FileExistsError as e:
                logging.error(f"{e}")
            except Exception as e:
                logging.exception(f"{e}")

            srcfile = POC_DIR + file

            shutil.copy(srcfile, dstdir)
            metafile.write(file + " moved to another git repo\n\t")
            os.remove(srcfile)
            logging.debug(f"{srcfile} file moved to the directory {dstroot}.")

        os.chdir(dstroot)
        print(dstroot)
        #exit()
        os.system("git status")
        os.system("git add .")
        #os.system("git commit -m 'automation commit of misc files'")
        #os.system("git push origin master")

def move_misc_files():
    #pass
    mf = MiscFiles()
    mf.clone_repo(POC_DIR, POC_REPO_URL)
    mf.unzip_files()
    misc_files_list = mf.track_misc_files()
    mf.move_misc_files(misc_files_list)
    

if __name__ == "__main__":
    move_misc_files()
